
//---------------------------------------------------------------------------------
//
//        This confidential and proprietary software may be used only              
//     as authorized by a licensing agreement from Everspin Technologies, Inc.                 
//     In the event of publication, the following notice is applicable:          
//                                                                               
//                    (C) COPYRIGHT 2016 Everspin Technologies, Inc.
//                          ALL RIGHTS RESERVED                                  
//                                                                               
//        The entire notice above must be reproduced on all authorized           
//       copies.        
//                                                         
//---------------------------------------------------------------------------------

Introduction:
The Everspin 1Mb QSPI behavioral model provides a means for customers to verify memory controller
functionality with QSPI ST-MRAM devices through simulation.

File Descriptions:
./readme.txt					this file
./EverspinSLA.txt				Everspin Software License Agreement

./rtl/mr10q010.v 				MR10Q010 1Mb QSPI MRAM behavioral model
./rtl/mr10q010.vh 				parameters file for the model

./sim/run_sim 					script to run simulation using NC-Verilog
./sim/tb_mr10q010.v 			test bench

Getting Started:
1) Extract the files
2) Compile and run the simulation using the included run_sim script.

		Usage: run_sim [-noiesl] [-simv] [-simv_only] [-notiming]
		       -noiesl      : don't force use of the IESL license
		       -simv        : run simvision after sim
		       -simv_only   : run simvision only, no sim
		       -nospecify   : run simulation without specify block
